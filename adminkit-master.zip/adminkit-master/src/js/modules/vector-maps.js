// Usage: https://github.com/themustafaomar/jsvectormap
import "jsvectormap"
import "jsvectormap/dist/maps/world.js"